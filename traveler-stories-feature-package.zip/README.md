# WEST TRAVEL — Our Latest Stories Feature Package

This package contains the complete, modular source files for the **"Our Latest Stories"** (`#traveler-stories`) section on the WEST TRAVEL homepage, matching the approved visual reference (`image_252b60.jpg`).

## Directory Layout

```
├── src/
│   ├── app/
│   │   └── page.tsx                         # Integrates <TravelerStoriesSection /> below <WhyWestTravelSection />
│   ├── components/
│   │   └── traveler-stories/
│   │       ├── TravelerStoriesSection.tsx   # Hanging Polaroid Carousel Component (with one-by-one circular replacement & damped pendulum settling swing)
│   │       ├── TravelerStoriesSection.module.css # Scoped CSS Module (theme tokens, 0.92:1 cards, catenary sag offsets, pendulum keyframes)
│   │       └── StoriesArtwork.tsx           # SVG clothesline rope, wooden clothespin, flight routes, Giza pyramids artwork, postmark
│   ├── config/
│   │   └── traveler-stories.ts              # Typed TravelerStoryRecord, SAMPLE_TRAVELER_STORIES dataset, and self-contained i18n
│   └── i18n/
│       └── hero-dictionary.ts               # Localized copy dictionaries (EN, TR, ES)
├── public/
│   └── images/
│       └── traveler-stories/                # 6 high-resolution 4:3 destination photographs (WebP + JPEG fallbacks)
│           ├── story-dubai-skyline.webp / .jpg
│           ├── story-luxor-temple.webp / .jpg
│           ├── story-giza-pyramids.webp / .jpg
│           ├── story-istanbul-sunset.webp / .jpg
│           ├── story-bosphorus-ferry.webp / .jpg
│           └── story-nile-felucca.webp / .jpg
└── docs/
    └── traveler-stories-section.md          # Architecture, card proportions, catenary curve & review-data integrity guide
```

## How to Apply

Simply copy the `src/`, `public/`, and `docs/` folders over your Next.js project root:
```bash
cp -r src public docs /path/to/your/west-travel-nextjs/
git add src public docs
git commit -m "feat(stories): implement Our Latest Stories hanging Polaroid clothesline section"
git push origin feat/traveler-stories
```
